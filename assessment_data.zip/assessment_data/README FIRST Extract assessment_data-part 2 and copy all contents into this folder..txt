Due to size limitations, 
please extract assessment_data-part2.zip and copy all contents into assessment_data(this folder).
